

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('header', 'Dashboard'); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-3">
            <div class="card">
                <div class="card-header bg-dark text-white text-center">Petugas</div>
                <div class="card-body">
                    <ul class="fa-ul">
                        <li style="margin-left:-50px;"><i class="fa-solid fa-user-pen fa-3x ml-6"></i></li>
                        <li class="text-center" style="margin-top:-50px;"><h1><?php echo e($petugas); ?></h1></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="card">
                <div class="card-header bg-dark text-white text-center">Masyarakat</div>
                <div class="card-body">
                    <ul class="fa-ul">
                        <li style="margin-left:-50px;"><i class="fa-solid fa-users fa-3x ml-6"></i></li>
                        <li class="text-center" style="margin-top:-50px;"><h1><?php echo e($masyarakat); ?></h1></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="card">
                <div class="card-header bg-dark text-white text-center">Pengaduan Proses</div>
                <div class="card-body">
                    <ul class="fa-ul">
                        <li style="margin-left:-50px;"><i class="fa-solid fa-clock-rotate-left fa-3x ml-6"></i></li>
                        <li class="text-center" style="margin-top:-50px;"><h1><?php echo e($proses); ?></h1></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="card">
                <div class="card-header bg-dark text-white text-center">Pengaduan Selesai</div>
                <div class="card-body">
                    <ul class="fa-ul">
                        <li style="margin-left:-50px;"><i class="fa-solid fa-clipboard-list fa-3x ml-6"></i></li>
                        <li class="text-center" style="margin-top:-50px;"><h1><?php echo e($selesai); ?></h1></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<script src="https://use.fontawesome.com/releases/vVERSION/js/all.js" data-mutate-approach="sync"></script>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7\htdocs\tugas_akhir\resources\views/Admin/Dashboard/index.blade.php ENDPATH**/ ?>