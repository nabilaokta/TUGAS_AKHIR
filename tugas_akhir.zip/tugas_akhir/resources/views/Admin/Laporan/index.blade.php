@extends('layouts.admin')

@section('title', 'Halaman Laporan')

@section('header', 'Laporan Pengaduan Masyarakat')

@section('content')
    <div class="row justify-content-center">
        <div class="col-lg-4 col-12">
            <div class="card" align="center">
                <div class="card-header bg-secondary" style="color:white;">
                    CARI BERDASARKAN TANGGAL
                </div>
                <div class="card-body">
                    <form action="{{route('laporan.getLaporan')}}" method="POST">
                        @csrf
                        <div class="form-group">
                            <input type="text" name="from" class="form-control text-center" placeholder="Tanggal Awal" onfocusin="(this.type='date')" onfocusout="(this.type='text')">
                        </div>
                        <div class="form-group">
                            <input type="text" name="to" class="form-control text-center" placeholder="Tanggal Akhir" onfocusin="(this.type='date')" onfocusout="(this.type='text')">
                        </div>
                        <button type="submit" class="btn btn-dark" style="width: 100%">CARI LAPORAN</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-10 col-12">
            <div class="card mt-3" >
                <div class="card-header bg-secondary" style="color:white;">
                    Data Berdasarkan Tanggal
                    <div class="float-right">
                        @if ($pengaduan ?? '')
                        <a href="{{ route('laporan.cetakLaporan', ['from' => $from, 'to' => $to]) }}"class="btn btn-danger btn-sm" style="">EXPORT TO PDF</a>
                        @endif
                    </div>
                </div>
                <div class="card-body">
                    @if ($pengaduan ?? '')
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Tanggal</th>
                                    <th>Isi Laporan</th>
                                    <th>Kategori Laporan</th>
                                    <th>Alamat</th>
                                    <th>Status</th>
                                </tr> 
                            </thead>
                            <tbody>
                                @foreach ($pengaduan as $k => $v)
                                    <tr>
                                        <td>{{ $k += 1 }}</td>
                                        <td>{{ $v->tgl_pengaduan }}</td>
                                        <td>{{ $v->isi_laporan }}</td>
                                        <td>{{ $v->kategori}}</td>
                                        <td>{{ $v->alamat }}</td>
                                        <td>
                                            @if ($v->status =='0')
                                                <a href="#" class="badge badge-danger">Pending</a>
                                            @elseif($v->status == 'proses')
                                                <a href="#" class"badge badge-warning">Proses</a>
                                            @else
                                                <a href="#" class="badge badge-success">Selesai</a>
                                            @endif
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    @else
                        <div class="text-center">
                            Tidak ada data
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
@endsection