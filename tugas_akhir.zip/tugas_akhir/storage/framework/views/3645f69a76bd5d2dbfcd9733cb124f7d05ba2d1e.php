<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css"
        integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">

    <title>Laporan Pengaduan </title>
</head>
<body>
    <div class="text-center">
        <h5>LAPORAN PENGADUAN MASYARAKAT </h5>
    </div>
    <div class="container">
        <table class="table table-striped table-hover table-bordered text-center">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Tanggal</th>
                    <th>Isi Laporan</th>
                    <th>Kategori Laporan</th>
                    <th>Alamat</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $pengaduan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($k += 1); ?></td>
                        <td><?php echo e($v-> tgl_pengaduan->format('d-M-Y')); ?></td>
                        <td><?php echo e($v->isi_laporan); ?></td>
                        <td><?php echo e($v->kategori); ?></td>
                        <td><?php echo e($v->alamat); ?></td>
                        <td><?php echo e($v->status == '0' ? 'Pending': ucwords($v->status)); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</body>
</html><?php /**PATH C:\xampp7\htdocs\tugas_akhir\resources\views/Admin/Laporan/cetak.blade.php ENDPATH**/ ?>