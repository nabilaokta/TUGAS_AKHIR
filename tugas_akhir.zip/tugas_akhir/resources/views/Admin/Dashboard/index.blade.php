@extends('layouts.admin')

@section('title', 'Dashboard')

@section('header', 'Dashboard')

@section('css')
<link rel="stylesheet" href="{{ asset('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css')}}">
@endsection

@section('content')
    <div class="row">
        <div class="col-lg-3">
            <div class="card">
                <div class="card-header bg-dark text-white text-center">Petugas</div>
                <div class="card-body">
                    <ul class="fa-ul">
                        <li style="margin-left:-50px;"><i class="fa-solid fa-user-pen fa-3x ml-6"></i></li>
                        <li class="text-center" style="margin-top:-50px;"><h1>{{$petugas}}</h1></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="card">
                <div class="card-header bg-dark text-white text-center">Masyarakat</div>
                <div class="card-body">
                    <ul class="fa-ul">
                        <li style="margin-left:-50px;"><i class="fa-solid fa-users fa-3x ml-6"></i></li>
                        <li class="text-center" style="margin-top:-50px;"><h1>{{$masyarakat}}</h1></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="card">
                <div class="card-header bg-dark text-white text-center">Pengaduan Proses</div>
                <div class="card-body">
                    <ul class="fa-ul">
                        <li style="margin-left:-50px;"><i class="fa-solid fa-clock-rotate-left fa-3x ml-6"></i></li>
                        <li class="text-center" style="margin-top:-50px;"><h1>{{$proses}}</h1></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="card">
                <div class="card-header bg-dark text-white text-center">Pengaduan Selesai</div>
                <div class="card-body">
                    <ul class="fa-ul">
                        <li style="margin-left:-50px;"><i class="fa-solid fa-clipboard-list fa-3x ml-6"></i></li>
                        <li class="text-center" style="margin-top:-50px;"><h1>{{$selesai}}</h1></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
@endsection

<script src="https://use.fontawesome.com/releases/vVERSION/js/all.js" data-mutate-approach="sync"></script>

