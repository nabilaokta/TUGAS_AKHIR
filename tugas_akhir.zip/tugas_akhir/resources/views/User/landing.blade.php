@extends('layouts.user')

@section('css')
<link rel="stylesheet" href="{{ asset('css/landing.css') }}">
<link rel="stylesheet" href="{{ asset('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css')}}">
@endsection

@section('title', 'Layanan - Pengaduan Masyarakat')

@section('content')
{{-- Section Header --}}
<section>
    <nav class="navbar navbar-expand-lg navbar-dark bg-secondary ">
        <div class="container">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">
                    <h4 class="semi-bold mb-0 text-white text-center ml-2">Layanan</h4>
                    <p class="times-new roman mt-0 text-white">Pengaduan Masyarakat</p>
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                    aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    @if(Auth::guard('masyarakat')->check())
                    <ul class="navbar-nav text-center ml-auto">
                        <li class="nav-item">
                            <a class="nav-link ml-3 text-white" href="{{ route('pekat.laporan') }}">Laporan</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link ml-3 text-white"
                                >{{ Auth::guard('masyarakat')->user()->nama }}</a>
                        </li>
                        <li>
                        <a href="{{ route('pekat.logout') }}" class="btn btn-secondary nav-link ml-3 text-white">Logout</a>
                        </li>
                    </ul>
                    @else
                    <ul class="navbar-nav text-center ml-auto mt-0">
                        <li>
                         <button type="button" class="btn btn-secondary" data-toggle="modal"
                            data-target="#loginModal">Login!</button>
                        </li>
                        <li class="nav-item"  style=" margin-left:20px;">
                            <a href="{{ route('pekat.formRegister') }}" class="btn btn-outline-purple">Daftar</a>
                        </li>
                    </ul>
                    @endauth
                </div>
            </div>
        </div>
    </nav>
</section>
    
<!-- <form action="">
    @csrf
    <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                    <img src="images/slide1.jpg" class="rounded float-right " style="width: 40%;" alt="...">
            </div>
            <div class="carousel-item">
                <img src="images/slide2.jpg" class="rounded float-right ml-" style="width: 40%;" alt="...">
            </div>
            <div class="carousel-item">
                <img src="..." class="d-block w-100" alt="...">
            </div>
        </div>
    </div>
</form> -->
    {{-- Modal --}}
<div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
                <h3 class="mt-3">Masuk terlebih dahulu</h3>
                <p>Silahkan masuk menggunakan akun yang sudah didaftarkan.</p>
                <form action="{{ route('pekat.login') }}" method="POST">
                    @csrf
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" name="username" id="username" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" name="password" id="password" class="form-control">
                    </div>
                    <button type="submit" class="btn btn-purple text-white mt-3" style="width: 100%">MASUK</button>
                </form>
                @if (Session::has('pesan'))
                <div class="alert alert-danger mt-2">
                    {{ Session::get('pesan') }}
                </div>
                @endif
            </div>
        </div>
    </div>
</div>
    <div class="container">
        <div class="content" >
            <img src="images/slide2.jpg" class="img-fluid float-right" width="420px" height="420px" alt="...">
        </div>
    </div>
    <div class="container pb-4 position-relative">
        <div class="row">
            <div class="col-md-8 py-5 my-4">
                <h2 class="font-weight-bold">Kami Membantu Anda <br> Mempermudah Membuat Laporan!</h2>
                <h6>Membuat laporan dengan mudah hanya dari rumah! </h6>
            </div>

            <div class="col-md-12 text-center">
                <div class="scroll-down d-inline-block primary-border text-center">
                    <div class="circle-scroll-down primary-bg d-inline-block">
                    </div>
                </div>
            </div>
        </div>
    </div>
        <div class="container">
            <div class="row">
                    @if ($errors->any())
                        @foreach ($errors->all() as $error)
                            <div class="alert alert-danger">{{ $error }}</div>
                        @endforeach
                    @endif

                    @if (Session::has('pengaduan'))
                        <div class="alert alert-{{ Session::get('type') }}">{{ Session::get('pengaduan') }}</div>
                    @endif
                <div class="col-md-8 text-center offset-md-2">
                    <h2>Masukkan Laporan Anda</h2>
                    <p class="montserrat" style="font-size: .75rem;">Laporan Anda Membantu Kami Untuk Cepat Menyelesaikan Masalah!</p>
                </div>
                <div class="col-md-10 offset-md-1 position-relative">
                    <div class="row">
                        <div class="col-12">
                            
                            <form action="{{ route('pekat.store') }}" method="POST" enctype="multipart/form-data">
                            @csrf
                                <div class="form-group">
                                    <textarea name="isi_laporan" id="msg" class="form-control form-control-lg p-4" style="font-size: .8rem; resize: none;" placeholder="Tulis Laporan!" rows="3"></textarea>
                                </div>
                                <div class="input-group mt-2 mb-2">
                                    <div class="input-group-prepend">
                                        <label class="input-group-text">Kategori Laporan</label>
                                        <select class="custom-select" name="kategori">
                                            <option>Silahkan Pilih</option>                                            
                                            <option value="politik">Politik</option>
                                            <option value="ekonomi">Ekonomi</option>
                                            <option value="social">Sosial</option>
                                            <option value="budaya">Budaya</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <textarea name="alamat" id="msg" class="form-control form-control-lg p-4" style="font-size: .8rem; resize: none;" placeholder="Masukkan Alamat" rows="3"></textarea>
                                <div class="form-group mt-2">
                                    <input type="file" name="foto" class="form-control">
                                </div>
                                <div class="text-center">
                                    <button type="submit" class="btn btn-secondary btn-lg btn-block">Kirim</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<footer class="container-fluid pt-5">
        <div class="container mb-2">
            <div class="row justify-content-center">
                <div class="col-md-4">
                    <h2 class="font-weight-bold text-center">Layanan<br>Masyarakat</h2>
                    <p class="mt-2 montserrat" style="font-size: .8rem;">Laporkan kendala anda demi kenyamanan bersama!</p>
                    <div class="text-center">
                        <p class="mt-3 icons-social" style="font-size: 1.6rem;">
                            <i class="mr-2 fa-solid fa-globe"></i>
                            <i class="mr-2 fa-solid fa-house-laptop"></i>
                            <i class="mr-2 fa-solid fa-envelope"></i>
                            <i class="mr-2 fa-solid fa-phone"></i>
                        </p>
                    </div>
                    <p class="text-center">Telp(0343-611974)<br>Email(layananmasyarakat.co.id)</p>
                    
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 text-center bg-secondary py-3">
                <p class="mb-0 text-white"></p>
            </div>
        </div>
</footer>
@endsection
<script src="https://use.fontawesome.com/releases/vVERSION/js/all.js" data-mutate-approach="sync"></script>
@section('js')
    @if (Session::has('pesan'))
    <script>
        $('#loginModal').modal('show');

    </script>
    @endif
@endsection