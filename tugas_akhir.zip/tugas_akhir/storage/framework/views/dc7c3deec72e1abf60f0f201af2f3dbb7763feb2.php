

<?php $__env->startSection('title', 'Detail Masyarakat'); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .text-primary:hover {
            text-decoration: underline;
        }
        .text-grey {
            color: #3d4044;
        }
        .text-grey:hover{
            color: #3d4044;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <a href="<?php echo e(route('masyarakat.index')); ?>" class="text-warning">Data Masyarakat</a>
    <a href="#" class="text-grey">/</a>
    <a href="#" class="text-black">Detail Masyarakat</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-6 col-12 ">
            <div class="card">
                <div class="class-header">
                <div class="card-header text-center bg-dark text-white">
                        Detail Masyarakat
                    </div>
                </div>
                <div class="card-body">
                    <table class="table">
                        <tbody>
                            <tr>
                                <th>NIK</th>
                                <td>:</td>
                                <td><?php echo e($masyarakat->nik); ?></td>
                            </tr>
                            <tr>
                                <th>Nama</th>
                                <td>:</td>
                                <td><?php echo e($masyarakat->nama); ?></td>
                            </tr>
                            <tr>
                                <th>Username</th>
                                <td>:</td>
                                <td><?php echo e($masyarakat->username); ?></td>
                            </tr>
                            <tr>
                                <th>No Telp</th>
                                <td>:</td>
                                <td><?php echo e($masyarakat->telp); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tugas_akhir\resources\views/Admin/Masyarakat/show.blade.php ENDPATH**/ ?>