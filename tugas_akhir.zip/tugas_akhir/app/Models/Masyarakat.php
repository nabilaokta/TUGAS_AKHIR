<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory; 
use Illuminate\foundation\Auth\User as Authenticatable;

class Masyarakat extends Authenticatable
{
    use HasFactory;

    protected $table ='masyarakat'; 

    protected $primaryKey ='nik';
    
    protected $fillable =[
        'nik',
        'nama',
        'username',
        'password',
        'telp',
    ];   

    function getNik(){
        return sprintf("%05d", $this->attributes['nik']);
    }
}
